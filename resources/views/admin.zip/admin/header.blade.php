<nav>
    <ul>
        <li><a href="{{ route('admin') }}">Trang Chủ</a></li>
        <li><a href="{{ route('productlist') }}">Sản phẩm</a></li>
        <li><a href="{{ route('categorylist') }}">Loại</a></li>
        <li><a href="users.html">Người dùng</a></li>
        <li><a href="updateProduct.html">Form Cập nhật</a></li>
    </ul>
</nav>