@extends('admin.layout2')
@section('content')


<main class="content">
    <div class="container-fluid p-0">
        <h1 class="h3 mb-3"><strong>Quản Trị</strong> Sản Phẩm</h1>       
        <a href="{{ route('product.create') }}" class="btn btn-primary">Thêm Sản Phẩm</a>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Image</th>
                        <th>Base Price</th>
                        <th class="text-danger bold">Discount Price</th>
                        <th>Description</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($products as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->name }}</td>
                        <td>{{ $item->category->name}}</td>
                        <td><img src="{{ asset('img/' . $item->img) }}" width="80" alt=""></td>
                        <td>{{ number_format($item->price,0,',','.')  }} vnđ</td>
                        <td class="text-danger" >{{ number_format($item->discount_price,0,',','.')  }} vnđ</td>
                        <td>{{ $item->description}}</td>
                        <td>{{ $item->created_at->format('d/m/Y H:i') }}</td>
                        <td>{{ $item->updated_at->format('d/m/Y H:i') }}</td>
                        <td class="action-icons">
                            <a href="{{ route('productupdateform',$item->id) }}">Edit</a>
                            -
                            <a href="{{ route('productdelete',$item->id) }}">Delete</a>
                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>
            <div class="d-flex justify-content-center mt-3">
                {{ $products->links('pagination::bootstrap-5') }}
            </div>
            
    </div>
</main>

@endsection
